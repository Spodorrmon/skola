steps = 0
numb = 10000

while True:
    def per(n, steps):
        if len(str(n)) == 1:
            
            if steps > 9:
                f = open("bruh.py", "a" )
                print(numb)
                f.write(str(numb)  + " :   " + str(steps) + "\n")
                print("steps: " , steps)
            return "DONE"
        
        digits = [int(i) for i in str(n)]
        result = 1
        for j in digits:
            result *= j
        steps = steps + 1
        per(result, steps)

    numb += 1
    per(numb, 0)
