steps = 0
numb = 0

while True:
    def per(n, steps):
        if len(str(n)) == 1:

            print(numb)
            print("steps: " , steps)
            return "DONE"
        
        digits = [int(i) for i in str(n)]
        result = 1
        for j in digits:
            result *= j
        steps = steps + 1
        print(result)
        per(result, steps)

    numb = int(input("Number: "))
    per(numb, 0)
#2677889
